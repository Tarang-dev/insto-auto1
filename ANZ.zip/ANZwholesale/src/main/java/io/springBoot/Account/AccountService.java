package io.springBoot.Account;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service 
public class AccountService {
	
	@Autowired
	private AccountRepository AccountRepo;

	
	public List<Account> getAllAccount() {
		
		List<Account> accounts =  new ArrayList<>();
		AccountRepo.findAll().forEach(accounts::add);
		
		return accounts;
	}
	
	public void createAccount(Account account) {
		AccountRepo.save(account);

	}

}
