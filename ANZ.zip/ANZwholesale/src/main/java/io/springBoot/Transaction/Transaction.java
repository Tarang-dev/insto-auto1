package io.springBoot.Transaction;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import io.springBoot.Account.Account;

@Entity
public class Transaction {
	
	@Id
	private Integer accountNumber;
	private String  accountName;
	private String  currency;
	private Integer debitAmount;
	@ManyToOne
	private Account account;
	public Integer getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Transaction(Integer accountNumber, String accountName, String accountType, Integer debitAmount) {
		super();
		this.accountNumber = accountNumber;
		this.accountName = accountName;
		this.currency = accountType;
		this.debitAmount = debitAmount;
		this.account = new Account(accountNumber, accountName, accountType);
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountType() {
		return currency;
	}

	public void setAccountType(String accountType) {
		this.currency = accountType;
	}
	
	
	 
	public Transaction() {
		
	}

	public Integer getDebitAmount() {
		return debitAmount;
	}

	public void setDebitAmount(Integer debitAmount) {
		this.debitAmount = debitAmount;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}
}
