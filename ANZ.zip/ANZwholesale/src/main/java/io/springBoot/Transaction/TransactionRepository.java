package io.springBoot.Transaction;

import java.util.List;

import org.springframework.data.repository.CrudRepository;


public interface TransactionRepository extends CrudRepository<Transaction, Integer>{
   public List<Transaction> findByaccountNumber(Integer id);
	

}
