package io.springBoot.Transaction;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service 
public class TransactionService {
	
	@Autowired
	private TransactionRepository TransactionRepo;

	
	public List<Transaction> getAllTransaction(Integer accountNumber) {
		List<Transaction> transaction = new ArrayList<>();
		
		TransactionRepo.findByaccountNumber(accountNumber).forEach(transaction::add);
		
		return transaction;
	}
	
	public void createTransaction(Transaction transaction) {
		TransactionRepo.save(transaction);

	}

	

}
