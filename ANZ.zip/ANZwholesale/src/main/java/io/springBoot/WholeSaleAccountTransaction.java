package io.springBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication 
public class WholeSaleAccountTransaction {
	public static void main(String[] args) {
		SpringApplication.run(WholeSaleAccountTransaction.class, args);
	}
}
